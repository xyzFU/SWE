public enum Type {
    Fire, Water, Poison;
}