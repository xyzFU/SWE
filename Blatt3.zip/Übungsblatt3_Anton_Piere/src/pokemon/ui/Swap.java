package pokemon.ui;

import java.util.Date;
import java.util.UUID;
/**Swap Klasse.*/
public class Swap {
  private String ID;
  private Date date;
  private String swapInformation;
  /**Constructor for creating Swap Objects*/
  public Swap(final Pokemon p1, final Pokemon p2) {
    this.ID = UUID.randomUUID().toString();
    Date actDate = new Date();
    this.date = actDate;
    this.swapInformation = "Trainer1:" + p1.getTrainerOfPokemon().getFirstname()
        + "," + p1.getTrainerOfPokemon().getLastname() + " tauschte:"
        + p1.getName() + " gegen " + p2.getName() + " von Trainer2 :"
        + p2.getTrainerOfPokemon().getFirstname() + ","
        + p2.getTrainerOfPokemon().getLastname() + "\n" + "Zum Zeitpunkt :"
        + actDate.toString() + "\n" + "SwapID:" + this.getID();

  }

  // getter&setter
  /**getter für ID.*/
  public String getID() {
    return ID;
  }
  /**setter für ID.*/
  public void setID(String iD) {
    ID = iD;
  }
  /**getter für date.*/
  public Date getDate() {
    return date;
  }
  /**setter für date.*/
  public void setDate(Date date) {
    this.date = date;
  }
  /**getter für swapInformation.*/
  public String getSwapInformation() {
    return swapInformation;
  }
  /**setter für swapInformation.*/
  public void setSwapInformation(String swapInformation) {
    this.swapInformation = swapInformation;
  }
  /**Tauschvorgange von Pokemon zweier verschiedenen Trainer und Typus.*/
  public void execute(final Pokemon p1, final Pokemon p2) {
    if (p1.isSwapAllow() == false) {
      System.out.println("Abbruch des Tauschvorganges:" + p1.getName()
          + " ist nicht zum Tausch berechtigt! ");
    } else if (p2.isSwapAllow() == false) {
      System.out.println("Abbruch des Tauschvorganges:" + p2.getName()
          + " ist nicht zum Tausch berechtigt! ");
    } else if (p1.getType() == p2.getType()) {
      System.out.println(p1.getName() + " kann nicht mit " + p2.getName()
          + " getauscht werden, da beide vom Typ " + p1.getType() + " sind!");
    } else if (p1.getTrainerOfPokemon() == p2.getTrainerOfPokemon()) {

      System.out.println(
          "Abbruch des Tauschvorganges,da beide Pokemon im "
          + "Besitz des gleichen Trainers sind");
    } else {
      Trainer temp1 = new Trainer(p1.getTrainerOfPokemon().getFirstname(),
          p1.getTrainerOfPokemon().getLastname(),
          p1.getTrainerOfPokemon().getBeutel()); // alten Trainer speichern
      p1.getTrainerOfPokemon().removePokemon(p1); // löschen von p1 aus dem
                                                  // Beutel des alten Besitzers
      p2.getTrainerOfPokemon().addPokemon(p1); // hinzufügen von p1 in des neuen
                                               // Trainer's Beutel

      p2.getTrainerOfPokemon().removePokemon(p2); // löschen von p1 aus dem
                                                  // Beutel des alten Besitzers
      temp1.addPokemon(p2);
      p1.addSwaps(this);
      p2.addSwaps(this);
    }

  }

}
