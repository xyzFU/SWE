package pokemon.ui;


import java.util.ArrayList;
import java.util.List;
/**Pokemon Klasse.*/
public class Pokemon {

  private String name;
  private Type type;
  private int number;
  private boolean belongingToTrainer;
  private Trainer trainerOfPokemon;
  private List<Swap> swaps;
  private boolean swapAllow;
  static private int nextNumber = 1;
  private List<Competition> competitions;
  private double tagesform;

  /**Constructor for Pokemon Objects.*/
  /**Pokemon Objects are called poke1,...,pokecntPokeBlngToTrainer,Pokemons without Trainer are called first poke1x,poke2x...etc..*/
  public Pokemon(final String name1, final Type type1, final boolean swapAllow1) {
    this.name = name1;
    this.type = type1;
    this.number = nextNumber;
    ++nextNumber;
    this.swapAllow = swapAllow1;
    swaps = new ArrayList();
    competitions=new ArrayList();
    
  }
  /**returns/outputs attributes of Pokemon Object.*/
  public String toString() {
    String output = this.name;
    System.out.println(this.name);
    System.out.println(this.type);
    System.out.println(this.number);
    return output;
  }
  /**getter Pokemon's name.*/
  public String getName() {
    return name;
  }
  /**setter for Pokemon's name.*/
  public void setName(String name1) { // Die this Referenz enthält die Adresse
                                     // unter der man den reservierten
    // Speicherbereich des aktuellen Objektes findet.
    // Das Schlüsselwort this liefert eine Referenz auf den Speicherbereich, in
    // dem
    // ein Objekt gespeichert ist zurück.
    this.name = name1;
  }
  /**getter Type.*/
  public Type getType() {
    return type;
  }
  /**set Type.*/
  public void setType(final Type type1) {
    this.type = type1;
  }
  /**getter for boolean isBelongingToTrainer.*/
  public boolean isBelongingToTrainer() {
    return belongingToTrainer;
  }
  /**setter for variable BelongingToTrainer.*/
  public void setBelongingToTrainer(boolean belongingToTrainer1) {
    this.belongingToTrainer = belongingToTrainer1;
  }
  /**getter f�r swapAllow.*/
  public boolean isSwapAllow() {
    return swapAllow;
  }
  /**setter für swapAllow.*/
  public void setSwapAllow(boolean swapAllow) {
    this.swapAllow = swapAllow;
  }

  // B2
  /**getter für Liste swaps.*/
  public List<Swap> getSwaps() {
    return swaps;
  }
  /**setter für Liste swaps.*/
  public void setSwaps(List<Swap> swaps) {
    this.swaps = swaps;
  } 
  
  /**hinzufügen neuer Swap Objekte zur Liste swaps.*/
  public void addSwaps(Swap swaps) {
    this.swaps.add(swaps);
  }
  /**gibt Trainer eines Pokemons zurück.*/
  public Trainer getTrainerOfPokemon() {
    return trainerOfPokemon;
  }
  /**legt Trainer eines Pokemons fest.*/
  public void setTrainerOfPokemon(Trainer trainerOfPokemon) {
    this.trainerOfPokemon = trainerOfPokemon;
  }
  /**getter für competitions liste.*/
  public List<Competition> getCompetitions() {
    return competitions;
  }
  /**setter für competitions liste.*/
  public void setCompetitions(List<Competition> competitions) {
    this.competitions = competitions;
  }
  /**gibt die aktuelle tagesform eines Pokemons zurück.*/
  public double gettagesform() {
    return tagesform = java.lang.Math.random();
  }
}
