package pokemon.ui;

import java.util.ArrayList;

/** main-Funktion. */
public class PokemonManager {


	public static void main(final String[] args) {

/*      Blatt 1+2
		ArrayList<Pokemon> Trainer1sBeutel = new ArrayList<Pokemon>();
		ArrayList<Pokemon> Trainer2sBeutel = new ArrayList<Pokemon>();
		Trainer Trainer1 = new Trainer("Trainer1", "Catchum", Trainer1sBeutel);
		Trainer Trainer2 = new Trainer("Prof", "Trainer2", Trainer2sBeutel);

		Pokemon poke1 = new Pokemon("Glumanda", Type.Fire, false);
		Pokemon poke2 = new Pokemon("Bisasam", Type.Poison, true);
		Pokemon poke3 = new Pokemon("Shiggy", Type.Water, true);
		Pokemon poke4 = new Pokemon("Hornliu", Type.Poison, true);
		Pokemon poke5 = new Pokemon("Karpador", Type.Water, true);

		Trainer2.addPokemon(poke1);
		Trainer2.addPokemon(poke2);
		Trainer2.addPokemon(poke3);
		Trainer2.removePokemon(poke1);
		Trainer1.addPokemon(poke1);
		Trainer1.addPokemon(poke5);
		Trainer1.getAllPokemon();
		Trainer1.addPokemon(poke4);
		Trainer1.getSpecificPokemon("Hornliu");
		Trainer1.getAllPoisonPokemon();
		// Übungsblatt2
		Swap swap1 = new Swap(poke2, poke4);
		Swap swap2 = new Swap(poke1, poke3);
		Swap swap3 = new Swap(poke5, poke2);

		System.out.println(swap1.getID());
		System.out.println(swap1.getDate());
		System.out.println(swap1.getSwapInformation());

		Trainer1.getAllPokemon();
		swap1.execute(poke2, poke4);
		swap2.execute(poke1, poke3);
		swap3.execute(poke5, poke2);
		Trainer1.getAllPokemon();
		Trainer2.getAllPokemon();

		Competition fight1 = new Competition(poke2, poke5);

		fight1.execute(poke2, poke5);

		Trainer1.getAllPokemon();
		Trainer2.getAllPokemon();
		*/
		//Blatt3
		Pokemon poke1 = new Pokemon("Glumanda", Type.Fire, false);
		Pokemon poke2 = new Pokemon("Bisasam", Type.Poison, true);
		Pokemon poke3 = new Pokemon("Shiggy", Type.Water, true);
		Pokemon poke4 = new Pokemon("Hornliu", Type.Poison, true);
		Pokemon poke5 = new Pokemon("Karpador", Type.Water, true);
        
		ArrayList<Pokemon> listOfPokemon =new ArrayList<Pokemon>();
		listOfPokemon.add(poke1);
		listOfPokemon.add(poke2);
		listOfPokemon.add(poke3);
		listOfPokemon.add(poke4);
		listOfPokemon.add(poke5);
		
		
		
        ArrayList<Pokemon> Trainer1sBeutel = new ArrayList<Pokemon>();
		ArrayList<Pokemon> Trainer2sBeutel = new ArrayList<Pokemon>();
		Trainer Trainer1= new Trainer("Ash", "Catchum", Trainer1sBeutel);
		Trainer Trainer2= new Trainer("Prof", "Eich", Trainer2sBeutel);
		Trainer Trainer3=new Trainer("Gary", "Eich", Trainer2sBeutel);

		Trainer2.addPokemon(poke1);
		Trainer2.addPokemon(poke2);
		Trainer2.addPokemon(poke3);
		Trainer1.addPokemon(poke4);
		Trainer1.addPokemon(poke5);
		
	    PokemonUI UI=new PokemonUI(listOfPokemon);


	}

}
