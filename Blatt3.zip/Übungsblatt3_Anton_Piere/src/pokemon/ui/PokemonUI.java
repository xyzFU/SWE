package pokemon.ui;
import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class PokemonUI {

     
	PokemonUI(ArrayList<Pokemon> listOfPokemon){
    Display display = new Display();
    Shell shell = new Shell(display);
    shell.setText("Pokemon Manager");
    Table table = new Table(shell, SWT.MULTI | SWT.BORDER
        | SWT.FULL_SELECTION);
    table.setLinesVisible(true);
    table.setHeaderVisible(true);
    String[] titles = { "Number", "Name", "Type", "Trainer", "Swaps",
        "SwapAllow", "Competitions" };
    for (int i = 0; i < titles.length; i++) {
      TableColumn column = new TableColumn(table, SWT.NONE);
      column.setText(titles[i]);
    }
 
    
    int count =listOfPokemon.size();
    
    for (int i = 0; i < listOfPokemon.size(); i++) {
      TableItem item = new TableItem(table, SWT.NONE);
      item.setText(0,""+i+"");
      item.setText(1,""+listOfPokemon.get(i).getName()+"");
      item.setText(2, ""+listOfPokemon.get(i).getType()+"");
      item.setText(3, ""+listOfPokemon.get(i).getTrainerOfPokemon().getFirstname()+" "+listOfPokemon.get(i).getTrainerOfPokemon().getLastname()+"");
      item.setText(4, ""+listOfPokemon.get(i).getSwaps().size()+"");
      item.setText(5, ""+listOfPokemon.get(i).isSwapAllow()+"");
      item.setText(6, ""+listOfPokemon.get(i).getCompetitions().size()+"");
    }
    for (int i = 0; i < titles.length; i++) {
      table.getColumn(i).pack();
    }
   
    
    
    table.setSize(table.computeSize(SWT.DEFAULT, 200));
    shell.pack();
    shell.open();
    while (!shell.isDisposed()) {
      if (!display.readAndDispatch())
        display.sleep();
    }
    display.dispose();
  }
}
