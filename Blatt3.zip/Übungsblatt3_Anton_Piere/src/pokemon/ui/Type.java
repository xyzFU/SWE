package pokemon.ui;

public enum Type {
    Fire, Water, Poison;
}