package pokemon.ui;

import java.util.ArrayList;

/**Klasse Trainer.*/
public class Trainer {
  private String firstname;
  private String lastname;
  private Pokemon pokemon;
  private ArrayList<Pokemon> Beutel;

  /**Constructor.*/
  /**Convention:Trainer objects are called Trainer1,...,Trainern with n=trainerCount*/
  public Trainer(final String firstname1, final String lastname1,
    final ArrayList<Pokemon> beutel) {
    this.firstname = firstname1;
    this.lastname = lastname1;
    this.Beutel = beutel;
    }

  
  /**getter für den Vornamen des aufrufenden Trainers.*/
  public String getFirstname() {
    return firstname;
  }
  /**setter für den Vornamen des aufrufenden Trainers.*/
  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }
  /**getter für den Nachnamen des aufrufenden Trainers.*/
  public String getLastname() {
    return lastname;
  }
  /**setter für den Nachnamen des aufrufenden Trainers.*/
  public void setLastname(String lastname) {
    this.lastname = lastname;
  }
  /**getter für Pokemon des aufrufenden Trainers.*/
  public Pokemon getPokemon() {
    return pokemon;
  }
  /**setter für Beutel des aufrufenden Trainers.*/
  public void setPokemon(Pokemon pokemon) {
    this.pokemon = pokemon;
  }
  /**getter für Beutel des aufrufenden Trainers.*/
  public ArrayList<Pokemon> getBeutel() {
    return Beutel;
  }
  /**setter für Beutel des aufrufenden Trainers.*/
  public void setBeutel(ArrayList<Pokemon> beutel) {
    Beutel = beutel;
  }
  

/**hinzufügen eines Pokemons zum Beutel des aufrufenden Trainers.*/
  public void addPokemon(Pokemon object) {
    if (object.isBelongingToTrainer()) {
      System.out.println(
          "Dieses Pokemon gehört bereits einem Trainer,bitte wähle ein "
          + "anderes Pokemon!");
    } else {
      this.Beutel.add(object);
      object.setBelongingToTrainer(true);
      object.setTrainerOfPokemon(this); // speichere den Pokemontrainer zu jedem Pokemon
      System.out.println(this.getFirstname() + "." + object.getName()
          + " wurde erfolgreich deinem Beutel hinzugefügt!");
    }
  }
 



/**Ausgabe eines bestimmten Pokemon des aufrufenden Trainers.*/
  public Pokemon getSpecificPokemon(final String pokename) {
    int ret = 0;
    for (int i = 0; i < this.Beutel.size(); ++i) {
      if (this.Beutel.get(i).getName() == pokename) {
        ret = i;
      }
    }
    System.out.println(this.Beutel.get(ret).getName()
        + " befindet sich in Pokeball Nummer:" + (ret));
    return this.Beutel.get(ret);
  }
  /**Ausgabe aller Pokemon des aufrufenden Trainers.*/
  public void getAllPokemon() {
    System.out.println(this.firstname
        + ".Die folgenden Pokemon befinden sich in deinem Besitz:");
    for (int i = 0; i < this.Beutel.size(); ++i) {
      System.out.println(this.Beutel.get(i).getName());
    }
  }
  /**Ausgabe aller Gift-Pokemon des aufrufenden Trainers.*/
  public void getAllPoisonPokemon(){
    System.out.println(this.firstname
        + ".Die folgenden Gift-Pokemon befinden sich in deinem Besitz:");
    for (int i = 0; i < this.Beutel.size(); ++i) {
      if (this.Beutel.get(i).getType() == Type.Poison) {
        System.out.println(this.Beutel.get(i).getName());
      }
    }
  }

  /**Bestimmtes Pokemon aus Beutel entfernen.*/
  public void removePokemon(final Pokemon object) {
    this.Beutel.remove(
        object.getTrainerOfPokemon().getSpecificPokemon(object.getName()));
    object.setTrainerOfPokemon(null);
    object.setBelongingToTrainer(false);
    System.out.println(this.getFirstname() + "." + "Dein " + object.getName()
        + " wurde aus deinem Beutel entfernt!");
  }
}
